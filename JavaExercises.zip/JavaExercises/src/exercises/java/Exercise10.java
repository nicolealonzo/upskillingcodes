package exercises.java;

public class Exercise10 {
    public static void main(String[] args) {
        int a,b,c,d;
        a = 1;
        b = 1;
        char nL = '\n';

        for(d = 0; d <= 9; d++){
            System.out.println(nL);
            for(c = 0; c <= 9; c++){
                System.out.println((a + d) + "^" + (b + c) + " = " + Math.pow((a + d), (b + c)));
            }
        }
    }
}