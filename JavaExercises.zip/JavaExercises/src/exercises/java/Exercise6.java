package exercises.java;

public class Exercise6 {
    public static void main(String[] args) {
        int m = 5;
        for(int i=1; i <= 10; i++){
            System.out.printf("%d * %d = %d \n",m,i,m*i);
        }
    }
}