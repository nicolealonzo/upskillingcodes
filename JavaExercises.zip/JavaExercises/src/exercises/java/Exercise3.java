package exercises.java;

public class Exercise3 {
    public static void main(String[] args) {
        int w = 101; //Decimal
        int x = 0123; //Octal
        int y = 0X496F; //Hexadecimal
        int z = 0b1011; //Binary

        long a = 123456789L;
        long b = 0x9ABCDEFL;
        long c = 01234567L;

        double d = 123.456;
        float f = 123.456f;

        char A = 'A';
        char LetterA = '\u0041';
        char LetterB = 66;

        char newLine = '\n';

        System.out.println(w);
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);

        System.out.println(newLine);

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

        System.out.println(newLine);

        System.out.println(d);
        System.out.println(f);

        System.out.println(newLine);

        System.out.println(A);
        System.out.println(LetterA);
        System.out.println(LetterB);
    }
}
