package exercises.java;

public class Exercise11 {
    public static void main(String[] args) {
        int a,b,c;
        double power;
        a = 1;
        b = 2;

        for(c = 0; c < 9; c++){
            power = Math.pow((a+c),b);
            System.out.println(power+" + "+power+" = "+(power+power));
        }
    }
}