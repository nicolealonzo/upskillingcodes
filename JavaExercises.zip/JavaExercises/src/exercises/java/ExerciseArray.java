package exercises.java;

public class ExerciseArray {
    public static void main(String[] args){
        int[] array = {2,4,6,};
        array(array);
        System.out.println(array[0]+" "+array[1]+" "+array[2]);
    }
    static void array(int[] array){
        array[0] = 1;
    }
}


