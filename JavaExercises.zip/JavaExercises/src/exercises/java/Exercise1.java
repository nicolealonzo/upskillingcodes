package exercises.java;

public class Exercise1 {
    public static void main(String[] args) {
        int min = 24*60;
        int sec = 24*3600;
        int mod = 167%2;
        System.out.println("minutes per day: " + min);
        System.out.println("seconds per day: " + sec);
        System.out.println("Modulo result: "+mod);
    }
}