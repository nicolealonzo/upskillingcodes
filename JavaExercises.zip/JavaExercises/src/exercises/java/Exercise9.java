package exercises.java;

public class Exercise9 {
    public static void main(String[] args) {
        int a,b,c,d;
        a = 1;
        b = 9;

        for(c = a; c <= b; c++){
            System.out.println("Multiplication Table of "+c);

            for(d = 1; d <= 10; d++){
                System.out.printf("%d * %d = %d \n",c,d,c*d);
            }
        }
    }
}