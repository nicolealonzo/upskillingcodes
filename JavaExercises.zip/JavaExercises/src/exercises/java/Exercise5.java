package exercises.java;

public class Exercise5 {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = 30;

        int sum = a + b + c;

        System.out.println("The sum of a+b+c is " +sum);
    }
}
