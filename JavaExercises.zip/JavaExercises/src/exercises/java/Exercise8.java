package exercises.java;

public class Exercise8 {
    public static void main(String[] args) {
        for(int i=1; i <= 10; i++){
            if(i%2==0){
                System.out.printf("%d is even.\n",i);
            }else if(i%2!=0){
                System.out.printf("%d is odd.\n",i);
            }
        }
    }
}