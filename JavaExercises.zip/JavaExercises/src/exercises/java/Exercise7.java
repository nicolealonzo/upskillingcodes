package exercises.java;

public class Exercise7 {
    public static void main(String[] args) {
        int m = 5;
        int count = 1;
        while(count <= 10){
            System.out.printf("%d * %d = %d \n",m,count,m*count);
            count++;
        }
    }
}