package exercises.java;

public class Main {
    public static void main(String[] args){
        Animal a1 = new Animal("Pororo","penguin",5,3.5);
        System.out.println(a1.printAnimal());
    }
}
class Animal{
    private String name = "";
    private String species = "";
    private int age = 0;
    private double weight = 0;

    public Animal(String name, String species, int age, double weight){
        this.name = name;
        this.species = species;
        this.age = age;
        this.weight = weight;
    }
    public String printAnimal(){
        return this.name + " " + this.species + " " + this.age + " " + this.weight;
    }
}


