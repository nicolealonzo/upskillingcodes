package exercises.java;

public class Exercise12 {
    public static void main(String[] args){
        String animal_name = "Annie";
        String animal_species = "aardvark";
        int patient_age = 3;
        String patient_weight = "55.45";

        System.out.printf("%s %s %d \n",animal_name,animal_species,patient_age);
        System.out.printf("%s %s %d %s \n",animal_name,animal_species,patient_age,patient_weight);
        replaceName(animal_name, animal_species, patient_age, patient_weight);
    }

    static void replaceName(String animal_name, String animal_species, int patient_age, String patient_weight){
        animal_name = animal_name.replace("Annie", "Bowie");
        animal_species = animal_species.replace("aardvark", "Canis Rufus");
        patient_age = 6;
        patient_weight = patient_weight.replace("55.45","47.95");
        System.out.printf("%s %s %d %s \n",animal_name,animal_species,patient_age,patient_weight);
    }
}
